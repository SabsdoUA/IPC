#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/socket.h>
#include <arpa/inet.h>

int main(int argc, char *argv[])
{
    if (argc != 4)
    {
        fprintf(stderr, "proc_d: Usage: %s <sem_id> <shm_id> <port1>\n", argv[0]);
        exit(1);
    }

    int sem_id = atoi(argv[1]);
    int shm_id = atoi(argv[2]);
    int port1 = atoi(argv[3]);

    char *shared_mem = (char *)shmat(shm_id, NULL, 0);
    if (shared_mem == (char *)-1)
    {
        perror("proc_d: shmat");
        exit(1);
    }

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1)
    {
        perror("proc_d: socket");
        exit(1);
    }

    struct sockaddr_in server;
    server.sin_family = AF_INET;
    server.sin_port = htons(port1);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
        perror("proc_d: connect");
        close(sock);
        exit(1);
    }

    printf("proc_d: Connected to server on port %d\n", port1);

    struct sembuf sem_op;
    char buffer[256];

    while (1)
    {
        sem_op.sem_num = 1;
        sem_op.sem_op = -1;
        sem_op.sem_flg = 0;
        semop(sem_id, &sem_op, 1);

        snprintf(buffer, sizeof(buffer), "%s", shared_mem);

        if (send(sock, buffer, strlen(buffer) + 1, 0) < 0)
        {
            perror("proc_d: send");
            break;
        }
        printf("proc_d: Sent to server: %s\n", buffer);

        sem_op.sem_num = 0;
        sem_op.sem_op = 1;
        sem_op.sem_flg = 0;
        semop(sem_id, &sem_op, 1);
    }

    close(sock);
    shmdt(shared_mem);

    return 0;
}
