#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <signal.h>

#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "proc_serv2: Usage: %s <port2> <output_file>\n", argv[0]);
        exit(1);
    }

    int port2 = atoi(argv[1]);
    const char *output_file = argv[2];

    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock == -1) {
        perror("proc_serv2: socket");
        exit(1);
    }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port2);
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("proc_serv2: bind");
        close(sock);
        exit(1);
    }

    printf("proc_serv2: Serv2 is listening on port %d...\n", port2);

    FILE *output = fopen(output_file, "w");
    if (output == NULL) {
        perror("proc_serv2: fopen");
        close(sock);
        exit(1);
    }

    char buffer[BUFFER_SIZE];
    struct sockaddr_in client_addr;
    socklen_t client_len = sizeof(client_addr);

    while (1) {
        ssize_t received = recvfrom(sock, buffer, BUFFER_SIZE - 1, 0,
                                    (struct sockaddr *)&client_addr, &client_len);
        if (received < 0) {
            perror("proc_serv2: recvfrom");
            break;
        }

        buffer[received] = '\0'; 
        printf("proc_serv2: Received: %s\n", buffer);

        fprintf(output, "%s\n", buffer);
        fflush(output); 

        if (strcmp(buffer, "Koncim\n") == 0) {
            printf("proc_serv2: Termination signal received. Stopping server.\n");
            break;
        }
    }

    fclose(output);
    close(sock);

    return 0;
}
