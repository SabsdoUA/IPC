#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/sem.h>
#include <sys/shm.h>

int main(int argc, char *argv[])
{
    if (argc != 4)
    {
        fprintf(stderr, "proc_t: Usage: %s <sem_id> <shm_id> <pipe_R2>\n", argv[0]);
        exit(1);
    }

    int sem_id = atoi(argv[1]);
    int shm_id = atoi(argv[2]);
    int r2_fd = atoi(argv[3]);

    char *shared_mem = (char *)shmat(shm_id, NULL, 0);
    if (shared_mem == (char *)-1)
    {
        perror("proc_t: shmat");
        exit(1);
    }

    struct sembuf sem_op;
    char read_buffer[256];
    char line_buffer[256];
    size_t line_length = 0;

    printf("proc_t: Waiting for data from R2...\n");

    while (1)
    {
        ssize_t bytes_read = read(r2_fd, read_buffer, sizeof(read_buffer) - 1);
        if (bytes_read <= 0)
        {
            if (bytes_read == 0)
                printf("proc_t: EOF (pipe closed by writer)\n");
            else
                perror("proc_t: read");
            break;
        }

        read_buffer[bytes_read] = '\0';

        for (ssize_t i = 0; i < bytes_read; i++)
        {
            if (read_buffer[i] == '\n')
            {
                line_buffer[line_length] = '\0';

                sem_op.sem_num = 0;
                sem_op.sem_op = -1;
                sem_op.sem_flg = 0;
                semop(sem_id, &sem_op, 1);

                snprintf(shared_mem, 256, "%s", line_buffer);
                printf("proc_t: Wrote to shared memory: %s\n", line_buffer);

                sem_op.sem_num = 1;
                sem_op.sem_op = 1;
                sem_op.sem_flg = 0;
                semop(sem_id, &sem_op, 1);

                line_length = 0;
            }
            else
            {
                if (line_length < sizeof(line_buffer) - 1)
                {
                    line_buffer[line_length++] = read_buffer[i];
                }
            }
        }
    }


    printf("proc_t: EOF\n");

    shmdt(shared_mem);
    close(r2_fd);
    return 0;
}
