#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>

volatile sig_atomic_t got_signal = 0;

void sigusr1_handler(int signo)
{
    if (signo == SIGUSR1)
        got_signal = 1;
}
int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        fprintf(stderr, "Proc_p1: Usage: %s <pipe_R2> <file>\n", argv[0]);
        exit(1);
    }

    int r1_fd = atoi(argv[1]);
    const char *filename = argv[2];

    printf("Proc_p2: Pipe R2: %d\n", r1_fd);
    printf("Proc_p2: File: %s\n", filename);

    FILE *f = fopen(filename, "r");
    if (!f)
    {
        perror("Proc_p2: fopen");
        exit(1);
    }

    struct sigaction sa;
    sa.sa_handler = sigusr1_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    if (sigaction(SIGUSR1, &sa, NULL) == -1) {
        perror("Error setting handler for SIGUSR1");
        exit(1);
    }

    char word[256];
    while (1)
    {
        pause();

        if (got_signal == -1)
        {
            printf("Proc_p2: got stop signal\n");
            break;
        }

        if (!got_signal)
            continue;

        got_signal = 0;
        if (fscanf(f, "%255s", word) == 1)
        {
            printf("Proc_p2: Writing word: %s with length %ld\n", word, strlen(word));
            write(r1_fd, word, strlen(word));
            write(r1_fd, "\n", 1);
        }
        else
        {
            printf("Proc_p2: EOF\n");
            break;
        }
    }

    fclose(f);
    return 0;
}
