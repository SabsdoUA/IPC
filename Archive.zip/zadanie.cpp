#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/wait.h>

volatile sig_atomic_t ready_count = 0;

void sigusr1_handler(int signo)
{
    ready_count++;
    printf("Zadanie: Received SIGUSR1 (Ready signal). Ready count: %d\n", ready_count);
}

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        fprintf(stderr, "Zadanie: Usage: %s <port1> <port2>\n", argv[0]);
        return 1;
    }

    struct sigaction sa;
    sa.sa_handler = sigusr1_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    if (sigaction(SIGUSR1, &sa, NULL) == -1)
    {
        perror("Zadanie: sigaction");
        exit(1);
    }

    int port1 = atoi(argv[1]);
    int port2 = atoi(argv[2]);
    char port1_str[16], port2_str[16];
    sprintf(port1_str, "%d", port1);
    sprintf(port2_str, "%d", port2);

    printf("Zadanie: Port1: %d\n", port1);
    printf("Zadanie: Port2: %d\n", port2);

    int fd_R1[2], fd_R2[2];
    if (pipe(fd_R1) == -1 || pipe(fd_R2) == -1)
    {
        perror("Zadanie: pipe");
        exit(1);
    }
    printf("Zadanie: created pipe R1: %d %d\n", fd_R1[0], fd_R1[1]);
    printf("Zadanie: created pipe R2: %d %d\n", fd_R2[0], fd_R2[1]);

    char r1_write[16], r2_write[16], r1_read[16], r2_read[16];
    sprintf(r1_write, "%d", fd_R1[1]);
    sprintf(r2_write, "%d", fd_R2[1]);
    sprintf(r1_read, "%d", fd_R1[0]);
    sprintf(r2_read, "%d", fd_R2[0]);

    // char buffer[256];

    // write(fd_R1[1], "Hello from R1", 14);
    // read(fd_R1[0], buffer, sizeof(buffer));
    // printf("Read from R1: %s\n", buffer);

    pid_t p1_pid = fork();
    if (p1_pid == 0)
    {
        execl("./proc_p1", "./proc_p1", r1_write, "p1.txt", NULL);
        perror("Zadanie: exec proc_p1");
        exit(1);
    }

    printf("Zadanie: created procces P1: %d\n", p1_pid);

    pid_t p2_pid = fork();
    if (p2_pid == 0)
    {
        execl("./proc_p2", "./proc_p2", r1_write, "p2.txt", NULL);
        perror("Zadanie: exec proc_p2");
        exit(1);
    }
    printf("Zadanie: created procces P2: %d\n", p2_pid);

    char p1_pid_str[16], p2_pid_str[16];
    sprintf(p1_pid_str, "%d", p1_pid);
    sprintf(p2_pid_str, "%d", p2_pid);

    pid_t pr_pid = fork();
    if (pr_pid == 0)
    {
        execl("./proc_pr", "./proc_pr", p1_pid_str, p2_pid_str, r1_read, r2_write, NULL);
        perror("Zadanie: exec proc_pr");
        exit(1);
    }
    printf("Zadanie: created procces PR: %d\n", pr_pid);

    pause();

    int sem1_id = semget(IPC_PRIVATE, 2, IPC_CREAT | 0666);
    int sem2_id = semget(IPC_PRIVATE, 2, IPC_CREAT | 0666);
    if (sem1_id == -1 || sem2_id == -1)
    {
        perror("Zadanie: semget");
        exit(1);
    }

    semctl(sem1_id, 0, SETVAL, 1);
    semctl(sem1_id, 1, SETVAL, 0);
    semctl(sem2_id, 0, SETVAL, 1);
    semctl(sem2_id, 1, SETVAL, 0);
    printf("Zadanie: created semaphores: %d %d\n", sem1_id, sem2_id);

    int shm1_id = shmget(IPC_PRIVATE, 256, IPC_CREAT | 0666);
    int shm2_id = shmget(IPC_PRIVATE, 256, IPC_CREAT | 0666);
    if (shm1_id == -1 || shm2_id == -1)
    {
        perror("Zadanie: shmget");
        exit(1);
    }
    printf("Zadanie: created shared memory 1: %d\n", shm1_id);
    printf("Zadanie: created shared memory 2: %d\n", shm2_id);

    char shm1_id_str[16], shm2_id_str[16], sem1_id_str[16], sem2_id_str[16];
    sprintf(shm1_id_str, "%d", shm1_id);
    sprintf(shm2_id_str, "%d", shm2_id);
    sprintf(sem1_id_str, "%d", sem1_id);
    sprintf(sem2_id_str, "%d", sem2_id);

    pid_t t_pid = fork();
    if (t_pid == 0)
    {
        execl("./proc_t", "./proc_t", sem1_id_str, shm1_id_str, r2_read, NULL);
        perror("Zadanie: exec proc_t");
        exit(1);
    }
    printf("Zadanie: created procces T: %d\n", t_pid);

    pid_t s_pid = fork();
    if (s_pid == 0)
    {
        execl("./proc_s", "./proc_s", shm1_id_str, sem1_id_str, shm2_id_str, sem2_id_str, NULL);
        perror("Zadanie: exec proc_s");
        exit(1);
    }
    printf("Zadanie: created procces S: %d\n", s_pid);

    pause();

    pid_t serv1_pid = fork();
    if (serv1_pid == 0)
    {
        execl("./proc_serv1", "./proc_serv1", port1_str, port2_str, NULL);
        perror("Zadanie: exec proc_serv1");
        exit(1);
    }
    printf("Zadanie: created procces serv1: %d\n", serv1_pid);

    pause();

    pid_t d_pid = fork();
    if (d_pid == 0)
    {
        execl("./proc_d", "./proc_d", sem2_id_str, shm2_id_str, port1_str, NULL);
        perror("Zadanie: exec proc_d");
        exit(1);
    }
    printf("Zadanie: created procces D: %d\n", d_pid);

    pid_t serv2_pid = fork();
    if (serv2_pid == 0)
    {
        execl("./proc_serv2", "./proc_serv2", port2_str, "server_2.txt", NULL);
        perror("Zadanie: exec proc_serv2");
        exit(1);
    }

    printf("Zadanie: created procces serv2: %d\n", serv2_pid);

    waitpid(pr_pid, NULL, 0);
    printf("Zadanie: PR finished\n");
    sleep(2);

    kill(p1_pid, SIGTERM);
    kill(p2_pid, SIGTERM);
    kill(t_pid, SIGTERM);
    kill(s_pid, SIGTERM);
    kill(d_pid, SIGTERM);
    kill(serv1_pid, SIGTERM);
    kill(serv2_pid, SIGTERM);

    close(fd_R1[0]);
    close(fd_R1[1]);
    close(fd_R2[0]);
    close(fd_R2[1]);

    semctl(sem1_id, 0, IPC_RMID);
    semctl(sem2_id, 0, IPC_RMID);
    shmctl(shm1_id, IPC_RMID, NULL);
    shmctl(shm2_id, IPC_RMID, NULL);
    printf("Zadanie: finished\n");
    return 0;
}
